function [angle,dist]=Angle_FCs( Center )
temp=size(Center(:,1));
num=temp(1);
dist=zeros(num);
for i=1:num
    for j=1:num
        dist(i,j)=(Center(i,1)-Center(j,1))^2+(Center(i,2)-Center(j,2))^2;
    end
end
angle=1:num;
for i=1:num
    [temp,index]=sort(dist(i,:));
    angle(i)=(dist(i,index(2))+dist(i,index(3))-dist(index(2),index(3)))/2/sqrt(dist(i,index(2))*dist(i,index(3)));
end
angle=acos(angle)/pi*2*90;
ksdensity(angle)
hold on