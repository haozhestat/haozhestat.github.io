function [Center,Radius, Num_Center]=Center_Radius_FCs(Points_FCs,Cluster_Centers,Cluster,threshold) %bandWidth=20
% [Cluster_Centers,Cluster]=MeanShiftCluster(Points_FCs',bandWidth,0);
Num_Points=size(Points_FCs);
Num_Points=Num_Points(1);
Num_Cluster=max(Cluster);
Points_Cluster=[Points_FCs Cluster'];
Num_Points_Cluster=[];
for k=1:Num_Cluster
    l=size(Points_Cluster(Points_Cluster(:,3)==k));
    Num_Points_Cluster=[Num_Points_Cluster l(1)]; 
end
Num_Points_Cluster=Num_Points_Cluster';
Center=[];Radius=[];
for k=1:Num_Cluster
    if Num_Points_Cluster(k)>=threshold
        Center=[Center Cluster_Centers(:,k)];
        temp=Cluster_Centers(:,k);
        l=size(Points_Cluster(Points_Cluster(:,3)==k));
        r=0;
        for j=1:Num_Points
            if Points_Cluster(j,3)==k
                r=r+sqrt((Points_Cluster(j,1)-temp(1))^2+ (Points_Cluster(j,2)- temp(2))^2);
            end
        end
        r=r/l(1);
        Radius=[Radius r];
    end
end
Center=Center';
Num_Center=size(Center);
Num_Center=Num_Center(1);
scatter(Points_Cluster(:,1),Points_Cluster(:,2),2.5,'filled','g');
hold on;
scatter(Center(:,1),Center(:,2),13,'filled','r');