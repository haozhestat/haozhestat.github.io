function [Points_FCs,Num_Points,Image_Length,Image_Width] = Color_Data_FCs(Address_Image)
% Address_Image='D:\OIST\data\small.jpg';
origin_image = imread( Address_Image );
[Image_Length,Image_Width,temp] = size(origin_image);
Points_FCs = [];
for i = 1:Image_Length
    for j = 1:Image_Width
        if origin_image(i,j,1) >= 240&&origin_image(i,j,1) <=255&& ...,
                origin_image(i,j,2)>=225&&origin_image(i,j,2)<=245&& ...,
                origin_image(i,j,3)>=200&&origin_image(i,j,3)<=228 
%                 (origin_image(i,j,2)-origin_image(i,j,1))>=-36&&(origin_image(i,j,2)-origin_image(i,j,1))<=5&& ...,
%                 (origin_image(i,j,3)-0.9*origin_image(i,j,2))>=-40&&(origin_image(i,j,3)-0.9*origin_image(i,j,2))<=0&& ...,
%                 (origin_image(i,j,3)-origin_image(i,j,1))>=-60&&(origin_image(i,j,3)-origin_image(i,j,1))<=0
            Points_FCs = [Points_FCs, [i,j]'];
        end
    end
end
Points_FCs = Points_FCs';
Num_Points=size( Points_FCs );
imshow(origin_image)
hold on;
scatter(Points_FCs(:,2),Points_FCs(:,1),2)

imshow(origin_image);
hold on;
a=round(Center);
scatter(a(:,2),a(:,1),2)
c=[];
for k=1:Num_Points(1)
    temp=origin_image(Points_FCs(k,1),Points_FCs(k,2),:);
    c=[c [temp(1) temp(2) temp(3)]'];
end
c=c';
scatter3(c(:,1),c(:,2),c(:,3))
scatter(c(:,1),c(:,2))   
scatter(c(:,2),c(:,3))   
scatter(c(:,1),c(:,3))   
% 
% dlmwrite('D:\OIST\result\x.txt',c(:,1));
% dlmwrite('D:\OIST\result\y.txt',c(:,2));
% dlmwrite('D:\OIST\result\z.txt',c(:,3));
