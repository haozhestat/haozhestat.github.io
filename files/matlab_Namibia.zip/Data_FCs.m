function [Points_FCs,Num_Points,Image_Length,Image_Width] = Data_FCs(Address_Image,Threshold_Gray)
% Address_Image='D:\OIST\data\small.jpg';
% Threshold_Gray=232;
%0<=Threshold_Gray<=255
origin_image = imread( Address_Image );
gray_image = rgb2gray(origin_image);
[Image_Length,Image_Width] = size(gray_image);
Points_FCs = [];
for i = 1:Image_Length
    for j = 1:Image_Width
        if gray_image(i,j) >= Threshold_Gray %232
            Points_FCs = [Points_FCs, [i,j]'];
        end
    end
end
Points_FCs = Points_FCs';
Num_Points=size( Points_FCs );
imshow(origin_image)
hold on;
scatter(Points_FCs(:,2),Points_FCs(:,1),2)