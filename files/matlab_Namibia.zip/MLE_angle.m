%function F=MLE_angle(x)
angle=dlmread('D:/OIST/result/angle_small.txt');
n=size(angle);n=n(1);
%k=sym('k');
k=2;
%syms k;
%F=[symsum(exp(-(angle(k)-x(1))^2/(2*x(3)))*(angle(k)-x(1))/(exp(-(angle(k)-x(1))^2/(2*x(3)))+exp(-(angle(k)-x(2))^2/(2*x(3)))),k,1,100),symsum(exp(-(angle(k)-x(2))^2/(2*x(3)))*(angle(k)-x(2))/(exp(-(angle(k)-x(1))^2/(2*x(3)))+exp(-(angle(k)-x(2))^2/(2*x(3)))),k,1,100),symsum((exp(-(angle(k)-x(1))^2/(2*x(3)))*(angle(k)-x(1))^2+exp(-(angle(k)-x(2))^2/(2*x(3)))*(angle(k)-x(2))^2)/(exp(-(angle(k)-x(1))^2/(2*x(3)))+exp(-(angle(k)-x(2))^2/(2*x(3)))),k,1,100)];
F='[exp(-(angle(k)-x(1))^2/(2*x(3)))*(angle(k)-x(1))/(exp(-(angle(k)-x(1))^2/(2*x(3)))+exp(-(angle(k)-x(2))^2/(2*x(3)))),exp(-(angle(k)-x(2))^2/(2*x(3)))*(angle(k)-x(2))/(exp(-(angle(k)-x(1))^2/(2*x(3)))+exp(-(angle(k)-x(2))^2/(2*x(3)))),(exp(-(angle(k)-x(1))^2/(2*x(3)))*(angle(k)-x(1))^2+exp(-(angle(k)-x(2))^2/(2*x(3)))*(angle(k)-x(2))^2)/(exp(-(angle(k)-x(1))^2/(2*x(3)))+exp(-(angle(k)-x(2))^2/(2*x(3))))]';
fsolve(F,[60,150,0.4])