function [Nearest_Dist,dist]=Nearest_Dist_FCs(Center)
temp=size(Center(:,1));
num=temp(1);
dist=zeros(num);
for i=1:num
    for j=1:num
        dist(i,j)=sqrt((Center(i,1)-Center(j,1))^2+(Center(i,2)-Center(j,2))^2);
    end
end
Nearest_Dist=1:num;
for i=1:num
    [temp,index]=sort(dist(i,:));
    Nearest_Dist(i)=dist(i,index(2));
end
Nearest_Dist=Nearest_Dist';
% ksdensity(Nearest_Dist)
hold on