function [Random_Center]=Random_Simulation(Num_Center,Image_Length,Image_Width)%,Mean_Radius,Variance_Radius)
% Normrnd_Radius=1:Num_Center;%initialize
Random_Center=rand(Num_Center,2);%initialize
Random_Center(:,1)=Random_Center(:,1)*Image_Length;
Random_Center(:,2)=Random_Center(:,2)*Image_Width;
% for k=1:Num_Center
%     index=1;
%     while(index==1)
%         index=0;
%         Random_Center(k,1)=rand(1,1)*Image_Length;
%         Random_Center(k,2)=rand(1,1)*Image_Width;
%         Normrnd_Radius(k)=normrnd(Mean_Radius,sqrt(Variance_Radius),1,1);
%         for i=1:k
%             if(i~=k&&(Random_Center(i,1)-Random_Center(k,1))^2+(Random_Center(i,2)-Random_Center(k,2))^2<(Normrnd_Radius(i)+Normrnd_Radius(k))^2)
%                 index=1;
%                 break;
%             end
%         end
%     end  
% end


%
% Normrnd_Radius=normrnd(Mean_Radius,sqrt(Variance_Radius),Num_Center,1);
% index=1;
% while( index==1)
%     index=0;
%     Random_Center=rand(Num_Center,2);
%     Random_Center(:,1)=Random_Center(:,1)*Image_Length;
%     Random_Center(:,2)=Random_Center(:,2)*Image_Width;
%     for i=1:Num_Center
%         for j=1:Num_Center
%             if (i~=j&&(Random_Center(i,1)-Random_Center(j,1))^2+(Random_Center(i,2)-Random_Center(j,2))^2<(Normrnd_Radius(i)+Normrnd_Radius(j))^2)
%                 index=1;
%                 i
%                 break;
%             end
%         end
%     end
% end