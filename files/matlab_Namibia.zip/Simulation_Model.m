dt = DelaunayTri(Center(:,1),Center(:,2));
[Vertex,Edges]=voronoiDiagram(dt);
matrix=zeros(Num_Center);
for i=1:Num_Center
    for j=1:Num_Center
        if i~=j &&sum(ismember(Edges{i},Edges{j}))==2
            matrix(i,j)=1;
            matrix(j,i)=1;
        end
    end
end
save_matrix=matrix;
try_matrix=matrix;
%--------------------------------------------------------------------------------------------------
loop=10000;
combine_percentage=[];
for k=1:loop
    temp=randperm(Num_Center);
    divide=temp(1);
    extrusion=temp(2);
    if sum(try_matrix(extrusion,:))>2 &&sum(try_matrix(divide,:))>2
        %extrusion part
        polygon_type=sum(try_matrix(extrusion,:));
        neighbor=find(try_matrix(extrusion,:)==1);
        for i = 2:(polygon_type-1)
            for j=i:polygon_type
                if try_matrix(neighbor(i-1),neighbor(j))==1
                    save=neighbor(i);
                    neighbor(i)=neighbor(j);
                    neighbor(j)=save;
                end
            end
        end
        try_matrix(extrusion,:)=0;
        try_matrix(:,extrusion)=0;
        if polygon_type>3
            for i=2:(floor(polygon_type/2))
                try_matrix(neighbor(i),neighbor(polygon_type+2-i))=1;
                try_matrix(neighbor(polygon_type+2-i),neighbor(i))=1;
                try_matrix(neighbor(i),neighbor(polygon_type+1-i))=1;
                try_matrix(neighbor(polygon_type+1-i),neighbor(i))=1; 
            end
        end    
        % divide part
        polygon_type=sum(try_matrix(divide,:));
        if polygon_type>3
            son1=polygon_type-binornd(polygon_type-4,1/2);
            son2=polygon_type+4-son1;
        end
        if polygon_type==3
            son1=4;
            son2=3;
        end
        neighbor=find(try_matrix(divide,:)==1);
        for i = 2:(polygon_type-1)
            for j=i:polygon_type
                if try_matrix(neighbor(i-1),neighbor(j))==1
                    save=neighbor(i);
                    neighbor(i)=neighbor(j);
                    neighbor(j)=save;
                end
            end
        end
        try_matrix(divide,:)=0;
        try_matrix(:,divide)=0;

        try_matrix(divide,neighbor(1:(son1-1)))=1;
        try_matrix(neighbor(1:(son1-1)),divide)=1;

        try_matrix(divide,extrusion)=1;
        try_matrix(extrusion,divide)=1;

        try_matrix(extrusion,neighbor(1))=1;
        try_matrix(neighbor(1),extrusion)=1;

        try_matrix(extrusion,neighbor((son1-1):polygon_type))=1;
        try_matrix(neighbor((son1-1):polygon_type),extrusion)=1;     
    
        percentage=[];
        for i =3:15
            temp=size(find(sum(try_matrix,2)==i))/(Num_Center);
            percentage=[percentage [i temp(1)]'];
        end
        percentage=percentage';
        combine_percentage=[combine_percentage percentage(:,2)]; 
    end
end
plot(combine_percentage');



