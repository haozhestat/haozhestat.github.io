function [Vertex,Edges,Percentage_Polygon,Mean_Polygon]=Voronoi_Diagram(Center,Image_Length,Image_Width)
% [Random_Vertex,Random_Edges,Random_Percentage_Polygon,Random_Mean_Polygon]=Voronoi_Diagram(Random_Center,Image_Length,Image_Width);
Num = size(Center);
n=0;
for i = 1:Num(1)
    if Center(i,1) >Image_Length*0.05 && Center(i,1) <Image_Length*0.95 && Center(i,2) >Image_Width*0.05 && Center(i,2) <Image_Width*0.95
     n=n+1;
    end
end 
dt = DelaunayTri(Center(:,1),Center(:,2));
figure(1);
voronoi(dt);
[Vertex,Edges]=voronoiDiagram(dt);
Percentage_Polygon=[];
Mean_Polygon=0;
for j=3:10
    k=0;
    for i=1:Num(1)
        temp=size(Edges{i});
        if temp(2)==j && max(Vertex(Edges{i}))~=Inf && Center(i,1) >Image_Length*0.05 && Center(i,1) <Image_Length*0.95 && Center(i,2) >Image_Width*0.05 && Center(i,2) <Image_Width*0.95
            k=k+1;
        end
    end
    Percentage_Polygon=[Percentage_Polygon [j,k/n]' ];
    Mean_Polygon = Mean_Polygon + k/n*j;
end
Percentage_Polygon=Percentage_Polygon';
figure(2);
bar(Percentage_Polygon(:,2))
set(gca,'XTicklabel',{'3','4','5','6','7','8','9','10'})
xlabel('Polygon Class')
ylabel('Frequency')
grid on


