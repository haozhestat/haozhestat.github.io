angle=read.table('D:/OIST/result/Namibia_2/Namibia_2_angle.txt')
angle=as.matrix(angle)
par(mfrow=c(2,2))
plot(density(angle))

library(mixtools)
mixture_angle=normalmixEM(angle,lambda=0.5,mu=c(60,150),sigma=2)
plot.mixEM(mixture_angle,density=TRUE)
summary(mixture_angle)
