library(MASS)
center1=read.table('D:/OIST/result/Namibia_2/Namibia_2_center_1.txt')
center1=as.matrix(center1)
center2=read.table('D:/OIST/result/Namibia_2/Namibia_2_center_2.txt')
center2=as.matrix(center2)
center=cbind(center1,center2)
center=as.matrix(center)
library(deldir)
voronoi=deldir(center1,center2)
area=voronoi$summary[,"dir.area"]
area=area[area<12000]
#par(mfrow=c(2,2))
plot(density(area),main="Density Estimate of Area of Namibia 2")

fit=fitdistr(area,"gamma")
param=fit$estimate
param=as.matrix(param)
curve(dgamma(x,rate=param[2,1],shape=param[1,1]),from=0,to=16000,col="red",lty=5,add=T)

fit=fitdistr(area,"lognormal")
param=fit$estimate
param=as.matrix(param)
curve(dlnorm(x,mean=param[1,1],sd=param[2,1]),from=0,to=16000,col="green",lty=4,add=T)


fit=fitdistr(area,"weibull")
param=fit$estimate
param=as.matrix(param)
curve(dweibull(x,scale=param[2,1],shape=param[1,1]),from=0,to=16000,col="blue",lty=3,add=T)



fit=fitdistr(area,"normal")
param=fit$estimate
param=as.matrix(param)
curve(dnorm(x,m=param[1,1],sd=param[2,1]),from=0,to=16000,col="cyan",lty=1,add=T)
legend("topright", c("Data","lognorm", "Gamma", "Weibull","Normal"), lty = c(1,1,3,5,1), col = c("black","green","red","blue","cyan"))

plot(ecdf(area),main="Empirical Distribution of Area")