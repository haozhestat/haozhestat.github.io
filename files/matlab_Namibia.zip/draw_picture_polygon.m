y=[0	0	0.0004	0;
0.0235	0.0239	0.0242	0;
0.2522	0.2485	0.2590	0.2888;
0.4669	0.4668	0.4504	0.4640;
0.2208	0.2250	0.2231	0.2085;
0.0343	0.0334	0.0405	0.0359;
0.0022	0.0025	0.0025	0.0028;
0	0	0	0];

b=bar(y);
grid on;
set(gca,'XTickLabel',{'3','4','5','6','7','8','9','10'})			
legend('Namibia 2','Namibia 3','Namibia 4','Proliferating Epithelia');
xlabel('Polygon Class ');
ylabel('Frequency');
title('Distribution of Polygon Class');