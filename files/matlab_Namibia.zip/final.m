[Nearest_Dist,dist]=Nearest_Dist_FCs(Center);
[angle,dist]=Angle_FCs( Center );
ksdensity(Nearest_Dist);
title('Nearest Distance of Namibia 4');
figure(2);
ksdensity(angle);
title('Angle of Namibia 4');
figure(3);
ksdensity(Radius)
title('Radius of Namibia 4');
mean(Nearest_Dist)
mean(Radius)
mean(angle)