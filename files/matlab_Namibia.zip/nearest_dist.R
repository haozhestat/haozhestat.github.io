nearest_dist=read.table('D:/OIST/result/Namibia_2/Namibia_2_nearest_dist.txt')
nearest_dist=as.matrix(nearest_dist)
plot(density(nearest_dist),main="Density Estimate of Nearest dist of Namibia 2")

library(MASS)
fit=fitdistr(nearest_dist,"gamma")
param=fit$estimate
param=as.matrix(param)
curve(dgamma(x,rate=param[2,1],shape=param[1,1]),from=0,to=120,col="red",lty=5,add=T)

fit=fitdistr(nearest_dist,"weibull")
param=fit$estimate
param=as.matrix(param)
curve(dweibull(x,scale=param[2,1],shape=param[1,1]),from=0,to=120,col="blue",lty=3,add=T)

fit=fitdistr(nearest_dist,"normal")
param=fit$estimate
param=as.matrix(param)
curve(dnorm(x,m=param[1,1],sd=param[2,1]),from=0,to=120,col="cyan",lty=1,add=T)
legend("topright", c("Data", "Gamma", "Weibull","Normal"), lty = c(1,3,5,1), col = c("black","red","blue","cyan"))

