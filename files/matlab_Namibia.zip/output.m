%ouput

[Nearest_Dist,dist]=Nearest_Dist_FCs(Center);
[angle,dist]=Angle_FCs( Center );
dlmwrite('D:\OIST\result\Namibia_3\Namibia_3_center_1.txt',Center(:,1))
dlmwrite('D:\OIST\result\Namibia_3\Namibia_3_center_2.txt',Center(:,2))
dlmwrite('D:\OIST\result\Namibia_3\Namibia_3_radius.txt',Radius')
dlmwrite('D:\OIST\result\Namibia_3\Namibia_3_angle.txt',angle')
dlmwrite('D:\OIST\result\Namibia_3\Namibia_3_nearest_dist.txt',Nearest_Dist)

