tilePerim <- function (object) {
x <- object[["x"]]
y <- object[["y"]]
xx <- c(x,x[1])
yy <- c(y,y[1])
sum(sqrt((xx[-1] - x)^2 + (yy[-1] - y)^2))
}

center1=read.table('D:/OIST/result/Namibia_2/Namibia_2_center_1.txt')
center1=as.matrix(center1)
center2=read.table('D:/OIST/result/Namibia_2/Namibia_2_center_2.txt')
center2=as.matrix(center2)
center=cbind(center1,center2)
center=as.matrix(center)

library(deldir)
voronoi=deldir(center1,center2)
perims=sapply(tile.list(voronoi),tilePerim)
perims=perims[perims<500]
plot(density(perims),main="Density Estimate of Perimeters of Namibia 2")

fit=fitdistr(perims,"gamma")
param=fit$estimate
param=as.matrix(param)
curve(dgamma(x,rate=param[2,1],shape=param[1,1]),from=0,to=500,col="red",lty=5,add=T)

fit=fitdistr(perims,"weibull")
param=fit$estimate
param=as.matrix(param)
curve(dweibull(x,scale=param[2,1],shape=param[1,1]),from=0,to=500,col="blue",lty=3,add=T)

fit=fitdistr(perims,"normal")
param=fit$estimate
param=as.matrix(param)
curve(dnorm(x,m=param[1,1],sd=param[2,1]),from=0,to=500,col="cyan",lty=1,add=T)
legend("topright", c("Data", "Gamma", "Weibull","Normal"), lty = c(1,3,5,1), col = c("black","red","blue","cyan"))



