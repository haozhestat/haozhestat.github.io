radius=read.table('D:/OIST/result/Namibia_2/Namibia_2_radius.txt')
radius=as.matrix(radius)
plot(density(radius))
a=mean(radius)/var(radius);
b=mean(radius)*mean(radius)/var(radius);
curve(dgamma(x,scale=a,shape=b),from=0,to=40)
plot(density(radius),main="Density Estimate of Radius of Namibia 2")

library(MASS)
fit=fitdistr(radius,"gamma")
param=fit$estimate
param=as.matrix(param)
curve(dgamma(x,rate=param[2,1],shape=param[1,1]),from=0,to=40,col="red",lty=5,add=T)

fit=fitdistr(radius,"weibull")
param=fit$estimate
param=as.matrix(param)
curve(dweibull(x,scale=param[2,1],shape=param[1,1]),from=0,to=40,col="blue",lty=3,add=T)

fit=fitdistr(radius,"normal")
param=fit$estimate
param=as.matrix(param)
curve(dnorm(x,m=param[1,1],sd=param[2,1]),from=0,to=40,col="cyan",lty=1,add=T)
legend("topright", c("Data", "Gamma", "Weibull","Normal"), lty = c(1,3,5,1), col = c("black","red","blue","cyan"))
