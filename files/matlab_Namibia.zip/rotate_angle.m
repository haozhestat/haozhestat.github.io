function [rotate_angle]=rotate_angle( Center )
temp=size(Center(:,1));
num=temp(1);
dist=zeros(num);
for i=1:num
    for j=1:num
        dist(i,j)=(Center(i,1)-Center(j,1))^2+(Center(i,2)-Center(j,2))^2;
    end
end
rotate_angle=[];
for i=1:num
    [temp,index]=sort(dist(i,:));
    a = Center(index(2),1)-Center(i,1);
    b = Center(index(2),2)-Center(i,2);
    c=sqrt(a*a+b*b);
    rotate_angle=[rotate_angle [0 0]' [c 0]'];
    a=a/c;
    b=b/c;
    for j=3:7
        rotate_angle=[rotate_angle [a*(Center(index(j),1)-Center(i,1))+b*(Center(index(j),2)-Center(i,2)) -b*(Center(index(j),1)-Center(i,1))+a*(Center(index(j),2)-Center(i,2))]'];
    end    
end
rotate_angle=rotate_angle';
plot(rotate_angle(:,1),rotate_angle(:,2),'.','MarkerSize',4)
% hold on;
% plot(near(:,1),near(:,2),'r')
% figure(2)



% % plot(rotate_angle)
% plot(rotate_angle(:,1),rotate_angle(:,2),'.')
% figure(2)
% angle=1:num;
% for i =1:num
%     if rotate_angle(i,1)>0
%         angle(i)=atan(rotate_angle(i,2)/rotate_angle(i,1))/pi*180;
%     end
%     if rotate_angle(i,1)==0&&rotate_angle(i,2)>0
%         angle(i)=90;
%     end
%     if rotate_angle(i,1)==0&&rotate_angle(i,2)<0
%         angle(i)=-90;
%     end
%     if rotate_angle(i,1)<0&&rotate_angle(i,2)>0
%         angle(i)=atan(rotate_angle(i,2)/rotate_angle(i,1))/pi*180+180;
%     end
%     if rotate_angle(i,1)<0&&rotate_angle(i,2)<0
%         angle(i)=atan(rotate_angle(i,2)/rotate_angle(i,1))/pi*180-180;
%     end
% end
% ksdensity(angle);
% dlmwrite('D:\OIST\result\rotate_angle.txt',angle')
% a=[];
% for i=-179:1:179
%     b=0;
%     for j=1:num
%         if angle(j)<(i+0.5)&&angle(j)>=(i-0.5)
%             b=b+1;
%         end
%     end
%     a=[a [cos(i/180*pi) sin(i/180*pi) i b]'];
% end
% a=a';
% a(:,4)=a(:,4)/num;
% plot3(a(:,1),a(:,2),a(:,4))
% % set(gca,'ztick',[-180:30:180]);  
% figure(2)
% plot(a(:,3),a(:,4))
% set(gca,'xtick',[-180:30:180]);   
% xlabel('Angle')
% ylabel('Frequency')

    
    





