Random_Center=rand(Num_Center,2);
Random_Center(:,1)=Random_Center(:,1)*Image_Length;
Random_Center(:,2)=Random_Center(:,2)*Image_Width;
Nearest_Dist=Nearest_Dist_FCs( Random_Center);
dlmwrite('random_center_1.txt',Random_Center(:,1));
dlmwrite('random_center_2.txt',Random_Center(:,2));