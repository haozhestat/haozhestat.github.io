origin=imread('D:\OIST\data\Namibia_4_black.jpg','jpg');
imshow(origin)
hold on
dt = DelaunayTri(Center(:,2),Center(:,1));
voronoi(dt);