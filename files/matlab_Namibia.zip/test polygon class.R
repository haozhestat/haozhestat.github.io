Namibia_4=c(0.2813,0.4538,0.2267,0.0353,0.0029);
cell=c(28.88,46.4,20.85,3.59,0.28);
Namibia_4=as.matrix(Namibia_4);cell=as.matrix(cell)
chisq.test(Namibia_4*2661,p=cell/100)


