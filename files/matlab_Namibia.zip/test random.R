center1=read.table('D:/OIST/result/Namibia_2/Namibia_2_gray_center_1.txt')
center1=as.matrix(center1)
center2=read.table('D:/OIST/result/Namibia_2/Namibia_2_gray_center_2.txt')
center2=as.matrix(center2)
center=cbind(center1,center2)
center=as.matrix(center)


#install.packages("spatstat")
library(spatstat)
points=as.ppp(center,c(0,max(center1)+1,0,max(center2)))
R=clarkevans(points,correction="Donnelly")
clarkevans.test(points,correction="Donnelly",alternative="greater")