origin=imread('D:\OIST\data\Namibia_2_black.jpg','jpg');
imshow(origin)
% hold on;
% scatter(Points_FCs(:,2),Points_FCs(:,1),2)
num=size(Center);
for i=1:num(1)
    for x=round(Center(i,1)-2.5):round(Center(i,1)+2.5)
        for y=round(Center(i,2)-2.5):round(Center(i,2)+2.5)
            if x >0 && y >0
                origin(x,y,:)=[0,0,0];
            end
        end
    end
end

num=size(Points_FCs);
for i=1:num(1)
    origin(Points_FCs(i,1),Points_FCs(i,2))=0;
end
imshow(origin)